public class ConcreteProduct extends Product {
    private String merk;
    private String model;

    public ConcreteProduct(String id, String beschrijving, boolean opVoorraad, String merk, String model) {
        super(id, beschrijving, opVoorraad);
        this.merk = merk;
        this.model = model;
    }

    @Override
    public String getDetails() {
        return "Merk: " + merk + ", Model: " + model;
    }

    @Override
    public double getPrice() {
        return 0;
    }

    @Override
    public double getInsurance() {
        return 0;
    }
}