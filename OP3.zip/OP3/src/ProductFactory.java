public abstract class ProductFactory {
    public abstract Product maakProduct(String id, String beschrijving, boolean opVoorraad);
}